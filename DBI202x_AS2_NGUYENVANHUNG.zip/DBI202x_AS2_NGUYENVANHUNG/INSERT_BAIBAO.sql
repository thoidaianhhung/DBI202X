﻿INSERT INTO BAIBAO VALUES ('BB01', 'PV01', 'BT01', N'Mỹ chống biến chủng Covid-19', 'Covid-19', N'Thế Giới',
N'Mỹ coi vaccine là vũ khí hữu hiệu nhất chống các biến chủng Covid-19.',
N'Cuộc đua toàn cầu nhằm sản xuất đủ vaccine Covid-19 cho 7 tỷ người sắp trở nên khó khăn. Tìm 
ra vaccine có thể ngăn ngừa những chủng virus mới hoặc có độc lực cao hơn chỉ
là một nửa cuộc chiến. Mỹ hiện nay hầu như không có khả năng sản xuất những loại
vaccine cải tiến hay những mũi tiêm bổ sung bên cạnh phiên bản gốc, theo các chuyên
gia vaccine và quan chức y tế chính quyền Tổng thống Joe Biden. Việc thiết lập cơ
sở hạ tầng nhằm tăng cường sản xuất vaccine có thể mất vài tháng, thậm chí vài năm
.', GETDATE()),
('BB02', 'PV02', 'BT02', N'Hãng xe Toyota', N'Quốc Tế', N'Kinh Doanh',
N'Nhà sáng lập Kiichiro Toyoda đã xây nền móng cho Toyota.',
N'Trận động đất Kanto – khu vực trung tâm kinh tế, chính trị lớn nhất của Nhật
- năm 1923 là một bước ngoặt với Kiichiro Toyoda, không chỉ vì những đau thương
nó mang tới mà còn vì những thay đổi nhận thức của người Nhật về ôtô. Khi hệ thống
đường sắt của Nhật bị tàn phá nặng nề do trận động đất, ôtô bỗng đóng vai trò quan
trọng.', GETDATE()),
('BB03', 'PV03', 'BT03', N'Bộ Chính trị khóa XIII', N'Chính Trị', N'Thời Sự',
N'4 Ủy viên Bộ Chính trị tham gia Ban Bí thư.',
N'Bốn Ủy viên Bộ Chính trị được phân công tham gia Ban Bí thư là bà Trương Thị Mai,
 ông Trần Cẩm Tú, ông Phan Đình Trạc và ông Nguyễn Hòa Bình.', GETDATE()),
('BB04', 'PV04', 'BT04', N'Vaccine AstraZeneca', N'Tin Tức', N'Sức Khỏe',
N'Ông Neil Astles, 59 tuổi, qua đời do bệnh đông máu sau khi tiêm vaccine
AstraZeneca.',
N'Theo bà, ông Astles là một luật sư khỏe mạnh. Ông được tiêm liều vaccine đầu tiên vào ngày 17/3, 
bị đau đầu và mất thị lực mắt phải một tuần sau đó. Những triệu chứng ngày một tệ hơn khiến ông phải
 đi cấp cứu tại Bệnh viện Đại học Hoàng gia Liverpool. Sau 10 ngày điều trị, ông qua đời do huyết
 khối xoang tĩnh mạch não, xuất huyết dưới nhện và hạ tiểu cầu.', GETDATE()),
('BB05', 'PV05', 'BT04', 'Covid-19', 'Covid-19', N'Thế Giới',
N'Mỹ coi vaccine là vũ khí hữu hiệu nhất chống các biến chủng Covid-19.',
N'Cuộc đua toàn cầu nhằm sản xuất đủ vaccine Covid-19 cho 7 tỷ người sắp trở nên khó khăn. Tìm 
ra vaccine có thể ngăn ngừa những chủng virus mới hoặc có độc lực cao hơn chỉ
là một nửa cuộc chiến. Mỹ hiện nay hầu như không có khả năng sản xuất những loại
vaccine cải tiến hay những mũi tiêm bổ sung bên cạnh phiên bản gốc, theo các chuyên
gia vaccine và quan chức y tế chính quyền Tổng thống Joe Biden. Việc thiết lập cơ
sở hạ tầng nhằm tăng cường sản xuất vaccine có thể mất vài tháng, thậm chí vài năm
.', GETDATE()),
('BB06', 'PV06', 'BT04', N'Covid-19 ở Mỹ', 'Covid-19', N'Thế giới',
N'Mỹ coi vaccine là vũ khí hữu hiệu nhất chống các biến chủng Covid-19',
N'Cuộc đua toàn cầu nhằm sản xuất đủ vaccine Covid-19 cho 7 tỷ người sắp trở nên khó khăn. Tìm 
ra vaccine có thể ngăn ngừa những chủng virus mới hoặc có độc lực cao hơn chỉ
là một nửa cuộc chiến. Mỹ hiện nay hầu như không có khả năng sản xuất những loại
vaccine cải tiến hay những mũi tiêm bổ sung bên cạnh phiên bản gốc, theo các chuyên
gia vaccine và quan chức y tế chính quyền Tổng thống Joe Biden. Việc thiết lập cơ
sở hạ tầng nhằm tăng cường sản xuất vaccine có thể mất vài tháng, thậm chí vài năm
.', GETDATE()),
('BB07', 'PV07', 'BT07', N'Covid-19 vaccine', 'Covid-19', N'Thế Giới',
N'Mỹ coi vaccine là vũ khí hữu hiệu nhất chống các biến chủng Covid-19.', N'Cuộc đua toàn cầu
nhằm sản xuất đủ vaccine Covid-19 cho 7 tỷ người sắp trở nên khó khăn. Tìm 
ra vaccine có thể ngăn ngừa những chủng virus mới hoặc có độc lực cao hơn chỉ
là một nửa cuộc chiến. Mỹ hiện nay hầu như không có khả năng sản xuất những loại
vaccine cải tiến hay những mũi tiêm bổ sung bên cạnh phiên bản gốc, theo các chuyên
gia vaccine và quan chức y tế chính quyền Tổng thống Joe Biden. Việc thiết lập cơ
sở hạ tầng nhằm tăng cường sản xuất vaccine có thể mất vài tháng, thậm chí vài năm
.', GETDATE()),
('BB08', 'PV08', 'BT08', N'Covid-19 biến chủng', 'Covid-19', N'Thế Giới',
N'Mỹ coi vaccine là vũ khí hữu hiệu nhất chống các biến chủng Covid-19.', N'Cuộc đua toàn cầu
nhằm sản xuất đủ vaccine Covid-19 cho 7 tỷ người sắp trở nên khó khăn. Tìm 
ra vaccine có thể ngăn ngừa những chủng virus mới hoặc có độc lực cao hơn chỉ
là một nửa cuộc chiến. Mỹ hiện nay hầu như không có khả năng sản xuất những loại
vaccine cải tiến hay những mũi tiêm bổ sung bên cạnh phiên bản gốc, theo các chuyên
gia vaccine và quan chức y tế chính quyền Tổng thống Joe Biden. Việc thiết lập cơ
sở hạ tầng nhằm tăng cường sản xuất vaccine có thể mất vài tháng, thậm chí vài năm
.', GETDATE()),
('BB09', 'PV09', 'BT09', N'Covid-19 lây lan', 'Covid-19', N'Thế Giới',
N'Mỹ coi vaccine là vũ khí hữu hiệu nhất chống các biến chủng Covid-19.', N'Cuộc đua toàn cầu
nhằm sản xuất đủ vaccine Covid-19 cho 7 tỷ người sắp trở nên khó khăn. Tìm 
ra vaccine có thể ngăn ngừa những chủng virus mới hoặc có độc lực cao hơn chỉ
là một nửa cuộc chiến. Mỹ hiện nay hầu như không có khả năng sản xuất những loại
vaccine cải tiến hay những mũi tiêm bổ sung bên cạnh phiên bản gốc, theo các chuyên
gia vaccine và quan chức y tế chính quyền Tổng thống Joe Biden. Việc thiết lập cơ
sở hạ tầng nhằm tăng cường sản xuất vaccine có thể mất vài tháng, thậm chí vài năm
.', GETDATE()),
('BB10', 'PV10', 'BT10', N'Cuộc chiến Covid-19', 'Covid-19', N'Thế Giới',
N'Mỹ coi vaccine là vũ khí hữu hiệu nhất chống các biến chủng Covid-19.', N'Cuộc đua toàn cầu
nhằm sản xuất đủ vaccine Covid-19 cho 7 tỷ người sắp trở nên khó khăn. Tìm 
ra vaccine có thể ngăn ngừa những chủng virus mới hoặc có độc lực cao hơn chỉ
là một nửa cuộc chiến. Mỹ hiện nay hầu như không có khả năng sản xuất những loại
vaccine cải tiến hay những mũi tiêm bổ sung bên cạnh phiên bản gốc, theo các chuyên
gia vaccine và quan chức y tế chính quyền Tổng thống Joe Biden. Việc thiết lập cơ
sở hạ tầng nhằm tăng cường sản xuất vaccine có thể mất vài tháng, thậm chí vài năm
.', GETDATE());