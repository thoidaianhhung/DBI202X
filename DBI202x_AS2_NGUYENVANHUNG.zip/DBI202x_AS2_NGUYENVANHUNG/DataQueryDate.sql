﻿--Tìm kiếm tất cả bài báo được viết vào năm 2021 dùng toán tử LIKE để tìm kiếm values bắt đầu từ 2021
SELECT * FROM BAIBAO WHERE NGAYDANG LIKE '2021%';