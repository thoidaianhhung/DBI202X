﻿INSERT INTO BIENTAPVIEN
VALUES ('BT01', N'Bùi Ngọc Anh', N'Hải Dương', '0973695828', '2000-07-24', 'anhbn@funix.edu.vn', N'Biên Tập Viên', '50000000'),
('BT02', N'Nguyễn Lan Anh', N'Hải Phòng', '0973009009', '2000-02-14', 'anhln@funix.edu.vn', N'Biên Tập Viên', '55000000'),
('BT03', N'Nguyễn Thùy Anh', N'Hà Nội', '0973300300', '2000-09-20', 'anhnt@funix.edu.vn', N'Biên Tập Viên',  '40000000'),
('BT04', N'Nguyễn Trọng Bảo', N'Vĩnh Phúc', '0973768989', '2000-08-10', 'baont@funix.edu.vn', N'Biên Tập Viên',  '60000000'),
('BT05', N'Hà Minh Giang', N'Thanh Hóa', '0973695829', '2000-03-24', 'gianghm@funix.edu.vn', N'Biên Tập Viên',  '45000000'),
('BT06', N'Lê Hoàng Hà', N'Hòa Bình', '0973695528', '2000-07-21', 'halh@funix.edu.vn', N'Biên Tập Viên',  '57000000'),
('BT07', N'Nguyễn Thị Khánh Huyền', N'Nam Định', '0973655828', '2000-07-24', 'huyenntk@funix.edu.vn', N'Biên Tập Viên',  '70000000'),
('BT08', N'Thái Thị Lan', N'Ninh Bình', '0973694828', '2000-03-24', 'lantt@funix.edu.vn', N'Biên Tập Viên',  '52000000'),
('BT09', N'Dương Tuyết Nhi', N'Nghệ An', '0973675828', '2000-11-24', 'nhidt@funix.edu.vn', N'Biên Tập Viên',  '65000000'),
('BT10', N'Đặng Thị Trâm', N'Quang Nam', '0973696828', '2000-12-24', 'tramdt@funix.edu.vn', N'Biên Tập Viên',  '70000000');